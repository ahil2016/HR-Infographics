/*
 Copyright (c) 2016-19 TIBCO Software Inc

 THIS SOFTWARE IS PROVIDED BY TIBCO SOFTWARE INC. ''AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 SHALL TIBCO SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//////////////////////////////////////////////////////////////////////////////
// #region Drawing Code
//

//
// Main Drawing Method
//

function renderCore ( sfdata )
{
    if ( resizing )
    {
        return;
    }

    // Log entering renderCore
    log ( "Entering renderCore" );

    // Extract the columns
    var columns = sfdata.columns;

    // Extract the data array section
    var chartdata = sfdata.data;

    // count the marked rows in the data set, needed later for marking rendering logic
    var markedRows = 0;
    for ( var i = 0; i < chartdata.length; i++ )
    {
        if ( chartdata[i].hints.marked )
        {
            markedRows = markedRows + 1;
        }
    }

    var width = window.innerWidth;
    var height = window.innerHeight;

    //
    // Replace the following code with actual Visualization code
    // This code just displays a summary of the data passed in to renderCore
    //
    displayWelcomeMessage ( document.getElementById ( "js_chart" ), sfdata );
}

// 
// #endregion Drawing Code
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// #region Marking Code
//

//
// This method receives the marking mode and marking rectangle coordinates
// on mouse-up when drawing a marking rectangle
//
function markModel ( markMode, rectangle )
{
	// Implementation of logic to call markIndices or markIndices2 goes here
}

// 
// #endregion Marking Code
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// #region Resizing Code
//

var resizing = false;

window.onresize = function ( event )
{
    resizing = true;
    if ( $ ( "#js_chart" ) )
    {
    }
    resizing = false;
}

// 
// #endregion Resizing Code
//////////////////////////////////////////////////////////////////////////////

//
// This is a sample visualization that indicates that JSViz is installed
// and configured correctly.  It is an example of how to draw standard
// HTML objects based on the data sent from JSViz.
//
function displayWelcomeMessage ( div, data )
{
    //console.log(data["data"][0]["items"][0]);
	var utilizationPercentage=data["data"][0]["items"][0];
    div.innerHTML = "";
    //
    // Display welcome message
    //
	var utilizationGuageContainer = jQuery('<div/>', {
    id: 'utilizationGuageContainer',
	"css" : {
        "height" : "128px",
		"width": "160px",
		"margin": "auto",
		"border": "1px solid #ccc",
		"border-radius": "4px",
		"box-shadow": "0 2px 8px 0 #ccc, 0 2px 6px 0 #ccc",
		"margin-top":"4px",
		"padding":"0px 18px"
    }
	}).appendTo('#js_chart');
	
	var guageColor=utilizationPercentage >= 62 ? '#84d9a3' : utilizationPercentage >=57 && utilizationPercentage <62 ? '#f8e487' : '#f58d8d' ;
    var g = new JustGage({
			id: "utilizationGuageContainer", 
    value: utilizationPercentage,
	min: 0,
    max: 100,
	symbol: "%",
	pointer: true,
	decimals: 1,
	counter: true,
	//relativeGaugeSize:true,
	noGradient:false,
	valueFontColor:"#4a4a4a",
	valueMinFontSize:16,
    
	
	levelColors: [guageColor]  //update colors based on the result out put
		});					  // Green - #41c572 Amber - #ffbf00  Red - #f58d8d
}
